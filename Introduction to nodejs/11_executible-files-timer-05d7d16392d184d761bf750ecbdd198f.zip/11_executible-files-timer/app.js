let time = 1;
console.log('Hello, I am Anurag.');
setInterval(() => {
  console.log(time++);
}, 1000);
